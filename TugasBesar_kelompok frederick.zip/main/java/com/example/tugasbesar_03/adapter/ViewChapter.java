package com.example.tugasbesar_03.adapter;

public interface ViewChapter {
    void getChapter(int position);
}
