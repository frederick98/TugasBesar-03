package com.example.tugasbesar_03.mangaModel;

import java.util.ArrayList;

public class Manga_Picture {
    protected ArrayList<ArrayList<Object>> picture;

    public Manga_Picture(){

    }

    public ArrayList<ArrayList<Object>> getPicture() {
        return picture;
    }

    public void setPicture(ArrayList<ArrayList<Object>> picture) {
        this.picture = picture;
    }
}
