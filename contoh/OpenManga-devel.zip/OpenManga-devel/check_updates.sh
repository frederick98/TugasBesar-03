#!/usr/bin/env bash
sh gradlew dependencyUpdates -Drevision=release