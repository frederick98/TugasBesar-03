package org.nv95.openmanga.di.qualifier

import org.koin.core.qualifier.Qualifier


object SupperCoroutine : Qualifier