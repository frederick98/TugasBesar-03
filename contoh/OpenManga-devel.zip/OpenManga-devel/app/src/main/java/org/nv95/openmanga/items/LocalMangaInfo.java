package org.nv95.openmanga.items;

/**
 * Created by nv95 on 02.07.16.
 */

public class LocalMangaInfo {

    public long id;
    public String name;
    public String path;
    public long size;
}
