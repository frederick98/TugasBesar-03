package org.nv95.openmanga.items;

import org.nv95.openmanga.feature.manga.domain.MangaInfo;

/**
 * Created by admin on 19.07.17.
 */

public class HistoryMangaInfo extends MangaInfo {

    public long timestamp;
    public int chapter;
    public int page;
}
