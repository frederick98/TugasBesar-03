package org.nv95.openmanga.components;

/**
 * Created by admin on 24.07.17.
 */

public interface IntegerPreference {

    int getValue();
}
