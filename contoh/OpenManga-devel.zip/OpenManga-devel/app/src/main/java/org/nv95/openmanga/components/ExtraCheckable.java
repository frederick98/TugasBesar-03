package org.nv95.openmanga.components;

import android.widget.Checkable;

/**
 * Created by admin on 20.07.17.
 */

public interface ExtraCheckable extends Checkable {

    void setCheckedAnimated(boolean checked);
}
