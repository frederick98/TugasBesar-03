package com.example.tugasbesar3;

public interface FragmentListener {
    void changePage(int page);
    void closeAplication();
}
