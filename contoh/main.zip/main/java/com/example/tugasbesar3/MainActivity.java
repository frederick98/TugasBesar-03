package com.example.tugasbesar3;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.View;

import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;

import android.view.Menu;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,FragmentListener {

    protected gridFragment gridFragment;
    protected detailManga detailManga;
    FragmentManager fragmentManager;
    protected ReadManga readManga;
    protected FavoriteFragment favoriteFragment;
    protected AboutFragment aboutFragment;
    FrameLayout container;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changePage(4);
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        this.gridFragment=gridFragment.newInstance("New GridFragment");
        this.detailManga=detailManga.newInstance("New DetailManga");
        this.readManga=readManga.newInstance("New ReadManga");
        this.favoriteFragment=favoriteFragment.newInstance("New FavoriteFragment");
        this.aboutFragment=aboutFragment.newInstance("new about");
        this.fragmentManager=this.getSupportFragmentManager();





        this.changePage(1);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            this.changePage(1);
        } else if (id == R.id.nav_fav) {
            this.changePage(4);
        } else if (id == R.id.nav_about) {
            this.changePage(5);
        } else if (id == R.id.nav_exit) {
            closeAplication();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void changePage(int page) {
        FragmentTransaction ft=this.fragmentManager.beginTransaction();
        if(page==1){
            if(this.gridFragment.isAdded()){
                ft.show(this.gridFragment);
            }
            else{
                ft.add(R.id.fragment_container,this.gridFragment);
            }
            if(this.detailManga.isAdded()){
                ft.hide(this.detailManga);
            }
            if(this.readManga.isAdded()){
                ft.hide(this.readManga);
            }
            if(this.favoriteFragment.isAdded()){
                ft.hide(this.favoriteFragment);
            }
            if(this.aboutFragment.isAdded()){
                ft.hide(this.aboutFragment);
            }

        }
        else if(page==2){
            if(this.detailManga.isAdded()){
                ft.show(this.detailManga);
            }
            else{
                ft.add(R.id.fragment_container,this.detailManga).addToBackStack(null);
            }
            if(this.gridFragment.isAdded()){
                ft.hide(this.gridFragment);
            }
            if(this.readManga.isAdded()){
                ft.hide(this.readManga);
            }
            if(this.favoriteFragment.isAdded()){
                ft.hide(this.favoriteFragment);
            }
            if(this.aboutFragment.isAdded()){
                ft.hide(this.aboutFragment);
            }

        } else if(page==3){

            if(this.readManga.isAdded()){
                ft.show(this.readManga);
            }
            else{
                ft.add(R.id.fragment_container,this.readManga).addToBackStack(null);
            }
            if(this.gridFragment.isAdded()){
                ft.hide(this.gridFragment);
            }
            if(this.detailManga.isAdded()){
                ft.hide(this.detailManga);
            }
            if(this.favoriteFragment.isAdded()){
                ft.hide(this.favoriteFragment);
            }
            if(this.aboutFragment.isAdded()){
                ft.hide(this.aboutFragment);
            }

        }
        else if(page==4){
            ft.replace(R.id.fragment_container,this.favoriteFragment);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            ft.addToBackStack(null);
//            if(this.favoriteFragment.isAdded()){
//                ft.show(this.favoriteFragment);
//            }
//            else{
//                ft.add(R.id.fragment_container,this.favoriteFragment).addToBackStack(null);
//            }
//            if(this.gridFragment.isAdded()){
//                ft.hide(this.gridFragment);
//            }
//            if(this.detailManga.isAdded()){
//                ft.hide(this.detailManga);
//            }
//            if(this.readManga.isAdded()){
//                ft.hide(this.readManga);
//            }

        } else if (page == 5) {
            ft.replace(R.id.fragment_container,this.aboutFragment);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            ft.addToBackStack(null);
        }
        ft.addToBackStack(null);
        ft.commit();

    }

    @Override
    public void closeAplication() {
        finish();
        System.exit(0);
    }
}
