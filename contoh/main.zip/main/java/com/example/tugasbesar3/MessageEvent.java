package com.example.tugasbesar3;


public  class MessageEvent{
    public static String message ;
}
