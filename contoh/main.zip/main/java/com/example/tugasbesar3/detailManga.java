package com.example.tugasbesar3;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class detailManga extends Fragment {

    FragmentListener fragmentListener;
    @BindView(R.id.tv_artist)
    TextView artist;
    @BindView(R.id.tv_author)
    TextView author;
    @BindView(R.id.tv_description)
    TextView description;
    @BindView(R.id.tv_total_chapter)
    TextView totalChapter;
    @BindView(R.id.tv_status)
    TextView status;
    @BindView(R.id.tv_categories)
    TextView categories;
    @BindView(R.id.tv_judul_manga)
    TextView judul;
    @BindView(R.id.iv_manga)
    ImageView gambarManga;
    @BindView(R.id.numbepic_chapter)
    NumberPicker numpick;
    @BindView(R.id.btn_detail)
    Button btn_detail;
    @BindView(R.id.ib_addFav)
    ImageButton addFav;
    Manga[] cek;
    MangaDataSource dataSource;
    String forFav;


    public detailManga(){

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.detail_manga,container,false);
        ButterKnife.bind(this,view);
        numpick.setMinValue(1);
        apiManga();

        btn_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int chapter=numpick.getValue();
                String idchapter=cek[chapter-1].getId();
                MessageEvent.message=idchapter;
                Log.d("message", MessageEvent.message);
                fragmentListener.changePage(3);

            }
        });
        dataSource=new MangaDataSource(this.getContext());
        addFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dataSource.open();
                Manga cek=new Manga(MessageEvent.message,(String) judul.getText(),forFav);
                dataSource.addFavorite(cek);
            }
        });
        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        apiManga();
    }

    public void onAttach(Context context){
        super.onAttach(context);

        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;

        }else{
            throw new ClassCastException(context.toString()+ " must implement FragmentListener");
        }

    }
    public static detailManga newInstance(String title){
        detailManga secondFragment = new detailManga();
        Bundle args = new Bundle();
        args.putString("title",title);
        secondFragment.setArguments(args);
        return secondFragment;
    }

    public void apiManga(){
        final String[] cat = new String[1];
        cat[0]="";
        String url = "https://www.mangaeden.com/api/manga/"+MessageEvent.message;
        StringRequest stringRequest =new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("chapters");
                    cek=new Manga[array.length()];

                    for (int i = 0 ; i < array.length();i++){
                        JSONArray object = array.getJSONArray(i);
                        Manga manga = new Manga(object.getString(3),"","");
                        cek[i]= manga;
                    }

                    JSONArray arrcat= jsonObject.getJSONArray("categories");

                    for(int i=0;i<arrcat.length();i++){
                        String cot=arrcat.getString(i);
                        cat[0] +=" "+cot;
                    }
                    totalChapter.setText(""+cek.length);
                    categories.setText(cat[0]);
                    String title=jsonObject.getString("title");
                    judul.setText(title);
                    String gambar=jsonObject.getString("image");
                    forFav=gambar;
                    if(!gambar.equals("null")) {
                        Glide.with(getView()).load("https://cdn.mangaeden.com/mangasimg/" + gambar).into(gambarManga);
                    }
                    else
                    {
                        gambarManga.setImageResource(R.drawable.ic_broken_image_black_24dp);
                    }
                    numpick.setMaxValue(cek.length);
                    String auth=jsonObject.getString("author");
                    author.setText(auth);
                    String art=jsonObject.getString("artist");
                    artist.setText(art);
                    art=jsonObject.getString("description");
                    description.setText(art);
                    art=jsonObject.getString("status");
                    if(art.equals("1")){
                        status.setText("OnGoing");
                    }
                    else{
                        status.setText("Complete");
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                Toast.makeText( getContext(), "GAGAL MANG internet terputus", Toast.LENGTH_LONG).show();
            }

        });
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);

    }

}