package com.example.tugasbesar3;

import android.content.Context;
import android.os.Bundle;
import android.util.EventLog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class gridFragment extends Fragment {

    @BindView(R.id.Grid_Contain)
    GridView gridView;
    Manga[] cek;
    gridAdapter adapter;
    ArrayList<Manga> mangaList;
    FragmentListener fragmentListener;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.grid_fragment, container, false);
        ButterKnife.bind(this,view);
        this.mangaList = new ArrayList<>();

        this.apiManga();

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MessageEvent.message = cek[position].getId()+"";
                fragmentListener.changePage(2);

            }
        });






    return view;
    }

    public static gridFragment newInstance(String title){
        gridFragment secondFragment = new gridFragment();
        Bundle args = new Bundle();
        args.putString("title",title);
        secondFragment.setArguments(args);


        return secondFragment;
    }
    public void onAttach(Context context){
        super.onAttach(context);


        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;

        }else{
            throw new ClassCastException(context.toString()+ " must implement FragmentListener");
        }

    }

    public void apiManga(){

        String url = "https://www.mangaeden.com/api/list/0/";
        StringRequest stringRequest =new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("manga");
                    cek=new Manga[array.length()];

                    for (int i = 0 ; i < array.length();i++){
                        JSONObject object = array.getJSONObject(i);
                        Manga manga = new Manga(object.getString("i"),object.getString("t"),object.getString("im"));
                        cek[i]= manga;
                        mangaList.add(manga);
                    }
                    adapter = new gridAdapter(getContext(), cek);
                    gridView.setAdapter(adapter);
                    gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            MessageEvent.message = cek[position].getId()+"";
                            fragmentListener.changePage(2);

                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                Toast.makeText( getContext(), "GAGAL MANG internet terputus", Toast.LENGTH_LONG).show();
            }

        });
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);

    }



}
