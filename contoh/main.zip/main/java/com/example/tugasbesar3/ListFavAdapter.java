package com.example.tugasbesar3;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ListFavAdapter extends BaseAdapter {
    private List<Manga> angka;
    @BindView(R.id.tv_judul_favorite)
    TextView judul;
    @BindView(R.id.iv_list_favorite)
    ImageView imageView;
    MangaDataSource dataSource;
    private Context context;
    LayoutInflater inflater;

    public ListFavAdapter(Context context, List<Manga> manga) {
        dataSource=new MangaDataSource(context);
        angka = manga;
        this.context=context;

    }
    @Override
    public int getCount () {

        return angka.size();
    }
    public void addLine (Manga newItem){
        //baru coba

        this.angka.add(newItem);
        dataSource.addFavorite(newItem);
        this.notifyDataSetChanged();
    }


    @Override
    public Object getItem ( int i){
        return angka.get(i);
    }

    @Override
    public long getItemId ( int i){
        return 0;
    }

    @Override
    public View getView ( int i, View view, ViewGroup viewGroup){
        if (inflater==null){
            inflater= (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        if(view==null){
            view=inflater.inflate(R.layout.favorite_item,null);
        }
        ButterKnife.bind(this,view);
        if(!angka.get(i).getGambar().equals("null")){
            Glide.with(view).load("https://cdn.mangaeden.com/mangasimg/"+angka.get(i).getGambar()).into(imageView);
        }
        else {
            imageView.setImageResource(R.drawable.ic_broken_image_black_24dp);
        }

        judul.setText(angka.get(i).getNama());

        return view;


    }

}
