package com.example.tugasbesar3;

public class Manga {
    protected String id;
    protected String Nama;
    protected String gambar;

    public Manga(String id, String nama, String gambar) {
        this.id = id;
        Nama = nama;
        this.gambar = gambar;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }
}

