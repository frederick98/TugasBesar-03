package com.example.tugasbesar3;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class AboutFragment extends Fragment {
    private String mParam1;
    private String mParam2;
    FragmentListener fragmentListener;

    public AboutFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_about, container, false);
    }
    public void onAttach(Context context){
        super.onAttach(context);


        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;

        }else{
            throw new ClassCastException(context.toString()+ " must implement FragmentListener");
        }

    }

    public static AboutFragment newInstance(String title){
        AboutFragment secondFragment = new AboutFragment();
        Bundle args = new Bundle();
        args.putString("title",title);
        secondFragment.setArguments(args);


        return secondFragment;
    }


}
