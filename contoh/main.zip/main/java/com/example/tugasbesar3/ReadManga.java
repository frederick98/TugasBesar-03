package com.example.tugasbesar3;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.RequiresPermission;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ReadManga extends Fragment {

    Manga[] gambar;
    @BindView(R.id.read_manga_list)
    ListView listViewRead;
    ListReadAdapter listReadAdapter;
    FragmentListener fragmentListener;

    public ReadManga(){

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.read_manga_fragment, container, false);
        ButterKnife.bind(this,view);
        apiManga();

        return view;
    }

    public static ReadManga newInstance(String title){
        ReadManga secondFragment=new ReadManga();
        Bundle args = new Bundle();
        args.putString("title",title);
        secondFragment.setArguments(args);
        return secondFragment;
    }
    public void onAttach(Context context){
        super.onAttach(context);

        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;

        }else{
            throw new ClassCastException(context.toString()+ " must implement FragmentListener");
        }

    }

    public void apiManga(){

        String url = "https://www.mangaeden.com/api/chapter/"+MessageEvent.message;
        StringRequest stringRequest =new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("images");
                    gambar=new Manga[array.length()];
                    int count=0;
                    for (int i = array.length()-1 ; i >=0;i--){
                        JSONArray object = array.getJSONArray(i);
                        Manga manga = new Manga("","",object.getString(1));
                        gambar[count]= manga;
                        count++;
                    }
                    listReadAdapter=new ListReadAdapter(getContext(),gambar);
                    listViewRead.setAdapter(listReadAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                Toast.makeText( getContext(), "GAGAL MANG internet terputus", Toast.LENGTH_LONG).show();
            }

        });
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);

    }
}
