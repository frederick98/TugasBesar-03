package com.example.tugasbesar3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public DatabaseHelper(Context context) {
        super(context, "db_manga", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createQuery = "CREATE TABLE IF NOT EXISTS Manga(" +
                "id TEXT PRIMARY KEY ," +
                "judul TEXT," +
                "gambar TEXT," +"user INTEGER"+
                ")";
        db.execSQL(createQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE If EXISTS Manga";
        db.execSQL(sql);
        onCreate(db);

    }

}
