package com.example.tugasbesar3;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import uk.co.senab.photoview.PhotoViewAttacher;

public class gridAdapter extends BaseAdapter {

    @BindView(R.id.iv_grid)
    ImageView imageView;
    @BindView(R.id.tv_grid)
    TextView textView;
    PhotoViewAttacher mAttacher;
    protected Context context;
    protected Manga[] manga;
    protected LayoutInflater inflater;

    public gridAdapter(Context context, Manga[] manga) {
        this.context = context;
        this.manga = manga;

    }

    @Override
    public int getCount() {
        return manga.length;
    }

    @Override
    public Object getItem(int position) {
        return manga[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (inflater==null){
            inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        if(convertView==null){
            convertView=inflater.inflate(R.layout.grid_item,null);
        }

        ButterKnife.bind(this,convertView);
        if(!this.manga[position].getGambar().equals("null")){
            Glide.with(convertView).load("https://cdn.mangaeden.com/mangasimg/"+this.manga[position].getGambar()).into(imageView);
        }
        else {
            imageView.setImageResource(R.drawable.ic_broken_image_black_24dp);
        }


        mAttacher =new PhotoViewAttacher(imageView);
        textView.setText(manga[position].getNama());
        return convertView;
    }

}

