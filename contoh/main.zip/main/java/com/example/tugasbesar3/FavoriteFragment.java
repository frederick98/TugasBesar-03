package com.example.tugasbesar3;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FavoriteFragment extends Fragment {


    @BindView(R.id.lv_favorite)
    ListView listView;
    List<Manga> cek;

    ListFavAdapter adapter;
    FragmentListener fragmentListener;


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.favorite_list, container, false);
        ButterKnife.bind(this,view);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MessageEvent.message=cek.get(position).getId();
                fragmentListener.changePage(2);
            }
        });




        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        final MangaDataSource dataSource=new MangaDataSource(this.getContext());
        dataSource.open();
        final List<Manga> mangas=dataSource.getAll();
        dataSource.close();
        cek=mangas;
        adapter= new ListFavAdapter(this.getContext(),mangas);
        listView.setAdapter(adapter);



    }

    public static FavoriteFragment newInstance(String title){
        FavoriteFragment secondFragment = new FavoriteFragment();
        Bundle args = new Bundle();
        args.putString("title",title);
        secondFragment.setArguments(args);


        return secondFragment;
    }
    public void onAttach(Context context){
        super.onAttach(context);


        if(context instanceof FragmentListener){
            this.fragmentListener = (FragmentListener) context;

        }else{
            throw new ClassCastException(context.toString()+ " must implement FragmentListener");
        }

    }
}
