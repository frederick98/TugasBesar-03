package com.example.tugasbesar3;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class MangaDataSource {
    private SQLiteDatabase db;
    private DatabaseHelper helper;


public MangaDataSource(Context context){
    helper=new DatabaseHelper(context);
}
void open(){
    db=helper.getWritableDatabase();
}
void close(){
helper.close();
}



    private Manga cursorToPerhitungan(Cursor cursor){
        Manga angka=new Manga("","","");
        angka.setId(cursor.getString(0));
        angka.setNama(cursor.getString(1));
        angka.setGambar(cursor.getString(2));
        return angka;
    }
    public List<Manga> getAll(){
        Cursor cursor = db.rawQuery("SELECT * FROM Manga",new String[]{});
        List<Manga> mangas = new ArrayList<Manga>();

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            mangas.add(cursorToPerhitungan(cursor));
            cursor.moveToNext();
        }

        return mangas;

    }
    public void addFavorite(Manga manga){

        open();

        db.execSQL("INSERT INTO  Manga (id,judul,gambar,user) VALUES('" + manga.getId() + "'," + "'" + manga.getNama() + "',"+"'"+manga.getGambar()+"'"+",null) ");

        close();
    }
}
